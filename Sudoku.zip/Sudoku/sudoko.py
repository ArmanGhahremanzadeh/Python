﻿import tkinter as tk
from tkinter import messagebox
import random
import time
import json
import os

GRID_SIZE = 9
SUBGRID_SIZE = 3
DIFFICULTY_LEVELS = {
    "Easy": 40,    
    "Medium": 50,  
    "Hard": 55     
}

class SudokuGame:
    def __init__(self, root):
        self.root = root
        self.root.title("Sudoku Game")
        self.entries = []
        self.fixed_cells = set()
        self.start_time = None
        self.solution_board = None
        self.timer_label = tk.Label(root, text="00:00", font=("Arial", 14))
        self.timer_label.grid(row=0, column=0, columnspan=9, pady=10)

        self.difficulty_var = tk.StringVar(value="Medium")
        tk.OptionMenu(root, self.difficulty_var, *DIFFICULTY_LEVELS.keys()).grid(row=1, column=0, columnspan=3)
        tk.Button(root, text="Start Game", command=self.start_game).grid(row=1, column=3, columnspan=3)
        tk.Button(root, text="Finish Game", command=self.check_solution).grid(row=1, column=6, columnspan=3)

        self.best_time_label = tk.Label(root, text="Best Time: --:--", font=("Arial", 12))
        self.best_time_label.grid(row=11, column=0, columnspan=9, pady=10)
        self.load_best_time()
        self.create_grid()

    def create_grid(self):
        for i in range(GRID_SIZE):
            row = []
            for j in range(GRID_SIZE):
                entry = tk.Entry(self.root, width=3, font=("Arial", 16), justify="center")
                entry.grid(row=i+2, column=j, padx=2, pady=2)
                entry.bind("<FocusOut>", self.validate_cell)  
                row.append(entry)
            self.entries.append(row)

    def start_game(self):
        self.clear_grid()
        self.fixed_cells.clear()
        self.start_time = time.time()
        self.update_timer()

        full_board = self.generate_full_board()
        self.solution_board = [row[:] for row in full_board]  
        num_to_remove = DIFFICULTY_LEVELS[self.difficulty_var.get()]
        board = self.remove_numbers(full_board, num_to_remove)

        for i in range(GRID_SIZE):
            for j in range(GRID_SIZE):
                if board[i][j] != 0:
                    self.entries[i][j].insert(0, str(board[i][j]))
                    self.entries[i][j].config(state="readonly", disabledforeground="black")
                    self.fixed_cells.add((i, j))

    def clear_grid(self):
        for i in range(GRID_SIZE):
            for j in range(GRID_SIZE):
                self.entries[i][j].config(state="normal", bg="white")
                self.entries[i][j].delete(0, tk.END)

    def update_timer(self):
        if self.start_time:
            elapsed = int(time.time() - self.start_time)
            minutes, seconds = divmod(elapsed, 60)
            self.timer_label.config(text=f"{minutes:02}:{seconds:02}")
            self.root.after(1000, self.update_timer)

    def validate_cell(self, event):
        for i in range(GRID_SIZE):
            for j in range(GRID_SIZE):
                if (i, j) not in self.fixed_cells:
                    val = self.entries[i][j].get()
                    if val and val.isdigit():
                        if int(val) != self.solution_board[i][j]:  
                            self.entries[i][j].config(bg="red")  
                        else:
                            self.entries[i][j].config(bg="white")  
                    else:
                        self.entries[i][j].config(bg="white")  

                    if val and val.isdigit():
                        self.entries[i][j].config(fg="blue")
                    else:
                        self.entries[i][j].config(fg="black")  

    def check_solution(self):
        success = True
        for i in range(GRID_SIZE):
            for j in range(GRID_SIZE):
                val = self.entries[i][j].get()
                if not val.isdigit():
                    continue
                if int(val) == self.solution_board[i][j]:
                    self.entries[i][j].config(bg="lightgreen")  
                else:
                    self.entries[i][j].config(bg="red") 
                    success = False

        board_filled = all(self.entries[i][j].get().isdigit() for i in range(GRID_SIZE) for j in range(GRID_SIZE))
        if success and board_filled:
            total_time = int(time.time() - self.start_time)
            minutes, seconds = divmod(total_time, 60)
            messagebox.showinfo("Success!", f"You completed the game in {minutes:02}:{seconds:02}!")
            self.save_best_time(total_time)
        elif not board_filled:
            messagebox.showinfo("Game Over", "You didn't complete the puzzle. Try again!")

    def generate_full_board(self):
        board = [[0 for _ in range(GRID_SIZE)] for _ in range(GRID_SIZE)]
        self.solve_board(board)
        return board

    def solve_board(self, board):
        for i in range(GRID_SIZE):
            for j in range(GRID_SIZE):
                if board[i][j] == 0:
                    nums = list(range(1, 10))
                    random.shuffle(nums)
                    for num in nums:
                        if self.is_valid(board, i, j, num):
                            board[i][j] = num
                            if self.solve_board(board):
                                return True
                            board[i][j] = 0
                    return False
        return True

    def remove_numbers(self, board, count):
        removed = 0
        new_board = [row[:] for row in board]
        while removed < count:
            i, j = random.randint(0, 8), random.randint(0, 8)
            if new_board[i][j] != 0:
                new_board[i][j] = 0
                removed += 1
        return new_board

    def is_valid(self, board, row, col, num):
        for i in range(GRID_SIZE):
            if board[row][i] == num or board[i][col] == num:
                return False
        start_row = row - row % SUBGRID_SIZE
        start_col = col - col % SUBGRID_SIZE
        for i in range(start_row, start_row + SUBGRID_SIZE):
            for j in range(start_col, start_col + SUBGRID_SIZE):
                if board[i][j] == num:
                    return False
        return True

    def save_best_time(self, total_time):
        best_file = 'sudoku_best.json'
        if os.path.exists(best_file):
            with open(best_file, 'r') as f:
                data = json.load(f)
        else:
            data = {}

        level = self.difficulty_var.get()
        if level not in data or total_time < data[level]:
            data[level] = total_time
            with open(best_file, 'w') as f:
                json.dump(data, f)
            self.best_time_label.config(text=f"Best Time: {total_time // 60:02}:{total_time % 60:02}")

    def load_best_time(self):
        best_file = 'sudoku_best.json'
        if os.path.exists(best_file):
            with open(best_file, 'r') as f:
                data = json.load(f)
            level = self.difficulty_var.get()
            if level in data:
                total_time = data[level]
                self.best_time_label.config(text=f"Best Time: {total_time // 60:02}:{total_time % 60:02}")

if __name__ == "__main__":
    root = tk.Tk()
    game = SudokuGame(root)
    root.mainloop()
