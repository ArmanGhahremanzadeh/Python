﻿import pygame
import random
import sys

pygame.init()

BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
WHITE = (255, 255, 255)

WIDTH, HEIGHT = 1200, 700
CELL_SIZE = 20

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Snake Game")

clock = pygame.time.Clock()
font = pygame.font.SysFont("Arial", 30)

pygame.mixer.init(frequency=22050, size=-16, channels=2, buffer=4096)
eat_sound = pygame.mixer.Sound("eat.mp3")
game_over_sound = pygame.mixer.Sound("gameover.mp3")
win_sound = pygame.mixer.Sound("win.mp3")

def draw_text(text, size, color, x, y):
    font_obj = pygame.font.SysFont("Arial", size)
    text_surface = font_obj.render(text, True, color)
    text_rect = text_surface.get_rect(center=(x, y))
    screen.blit(text_surface, text_rect)
    return text_rect

def draw_score(score):
    score_text = font.render(f"Score: {score}", True, WHITE)
    screen.blit(score_text, (10, 10))

def show_message(text, color):
    message = font.render(text, True, color)
    rect = message.get_rect(center=(WIDTH // 2, HEIGHT // 2))
    screen.blit(message, rect)
    pygame.display.update()
    pygame.time.wait(2000)

def get_new_apple(snake):
    while True:
        apple = (
            random.randint(0, (WIDTH - CELL_SIZE) // CELL_SIZE) * CELL_SIZE,
            random.randint(0, (HEIGHT - CELL_SIZE) // CELL_SIZE) * CELL_SIZE
        )
        if apple not in snake:
            return apple

def menu():
    while True:
        screen.fill(BLACK)
        draw_text("Choose Difficulty", 40, WHITE, WIDTH // 2, HEIGHT // 4)

        easy_btn = draw_text("1. Easy", 35, GREEN, WIDTH // 2, HEIGHT // 2 - 60)
        med_btn = draw_text("2. Medium", 35, WHITE, WIDTH // 2, HEIGHT // 2)
        hard_btn = draw_text("3. Hard", 35, RED, WIDTH // 2, HEIGHT // 2 + 60)

        pygame.display.update()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = pygame.mouse.get_pos()
                if easy_btn.collidepoint(mouse_pos):
                    return 10
                elif med_btn.collidepoint(mouse_pos):
                    return 15
                elif hard_btn.collidepoint(mouse_pos):
                    return 20
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1:
                    return 10
                elif event.key == pygame.K_2:
                    return 15
                elif event.key == pygame.K_3:
                    return 20

def reset_menu():
    while True:
        screen.fill(BLACK)
        reset_text = font.render("Press R to Reset or Q to Quit", True, WHITE)
        text_rect = reset_text.get_rect(center=(WIDTH // 2, HEIGHT // 2))
        screen.blit(reset_text, text_rect)
        pygame.display.update()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    return True
                elif event.key == pygame.K_q:
                    pygame.quit()
                    sys.exit()

def main():
    speed = menu()
    snake = [(100, 100)]
    direction = (CELL_SIZE, 0)
    next_direction = direction
    apple = get_new_apple(snake)
    score = 0
    WIN_SCORE = 50

    running = True
    while running:
        screen.fill(BLACK)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP and direction != (0, CELL_SIZE):
                    next_direction = (0, -CELL_SIZE)
                elif event.key == pygame.K_DOWN and direction != (0, -CELL_SIZE):
                    next_direction = (0, CELL_SIZE)
                elif event.key == pygame.K_LEFT and direction != (CELL_SIZE, 0):
                    next_direction = (-CELL_SIZE, 0)
                elif event.key == pygame.K_RIGHT and direction != (-CELL_SIZE, 0):
                    next_direction = (CELL_SIZE, 0)

        direction = next_direction
        head = (snake[0][0] + direction[0], snake[0][1] + direction[1])

        if not (0 <= head[0] < WIDTH and 0 <= head[1] < HEIGHT) or head in snake:
            show_message("Oops! Game Over!", RED)
            game_over_sound.play()
            running = False
            break

        snake.insert(0, head)

        if head == apple:
            score += 1
            speed += 0.7
            apple = get_new_apple(snake)
            eat_sound.play()
        else:
            snake.pop()

        if score >= WIN_SCORE:
            show_message("You Win!", GREEN)
            win_sound.play()
            running = False
            break

        for segment in snake:
            pygame.draw.rect(screen, GREEN, (*segment, CELL_SIZE, CELL_SIZE))

        pygame.draw.rect(screen, RED, (*apple, CELL_SIZE, CELL_SIZE))
        draw_score(score)
        pygame.display.update()
        clock.tick(speed)

    if reset_menu():
        main()

if __name__ == "__main__":
    main()
