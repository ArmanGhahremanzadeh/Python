import tkinter as tk
from tkinter import messagebox, Toplevel, Scrollbar, Text
from tkcalendar import DateEntry
import json
from datetime import datetime

APPOINTMENTS_FILE = "appointments.json"
user_info = {}

def load_appointments():
    try:
        with open(APPOINTMENTS_FILE, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return []

def save_appointments(data):
    with open(APPOINTMENTS_FILE, "w") as f:
        json.dump(data, f, indent=2)

def is_duplicate(national_id, date, time):
    appointments = load_appointments()
    for a in appointments:
        if a["national_id"] == national_id and a["date"] == date and a["time"] == time:
            return True
    return False

def open_appointment_window():
    for key, entry in patient_entries.items():
        user_info[key] = entry.get().strip()

    if not all([user_info["first_name"], user_info["last_name"], user_info["phone"], user_info["national_id"]]):
        messagebox.showerror("Error", "Please fill all required fields.")
        return

    if not user_info["phone"].isdigit() or len(user_info["phone"]) != 11:
        messagebox.showerror("Error", "Phone number must be 11 digits.")
        return

    appt_win = Toplevel(window)
    appt_win.title("Choose Appointment Time")
    appt_win.geometry("300x250")

    tk.Label(appt_win, text="Select Appointment Date").pack(pady=5)
    date_picker = DateEntry(appt_win, date_pattern='yyyy-mm-dd')
    date_picker.pack(pady=5)

    tk.Label(appt_win, text="Enter Time (e.g. 10:30)").pack(pady=5)
    entry_time = tk.Entry(appt_win)
    entry_time.pack(pady=5)

    def submit_final():
        date = date_picker.get()
        time = entry_time.get().strip()

        if not validate_time_format(time):
            messagebox.showerror("Error", "Invalid time format (HH:MM).")
            return

        if is_duplicate(user_info["national_id"], date, time):
            messagebox.showwarning("Duplicate", "Appointment already exists.")
            return

        appointment = {**user_info, "date": date, "time": time}
        appointments = load_appointments()
        appointments.append(appointment)
        save_appointments(appointments)
        messagebox.showinfo("Success", f"Appointment scheduled for {date} at {time}.")
        appt_win.destroy()

    tk.Button(appt_win, text="Confirm Appointment", bg="green", fg="white", command=submit_final).pack(pady=15)

def validate_time_format(t):
    import re
    return re.match(r"^(0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$", t)

def show_appointments():
    appointments = load_appointments()
    if not appointments:
        messagebox.showinfo("Appointments", "No appointments found.")
        return

    appointments.sort(key=lambda x: (x["date"], x["time"]))

    view_win = Toplevel(window)
    view_win.title("All Appointments")
    view_win.geometry("500x400")

    scrollbar = Scrollbar(view_win)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    text_area = Text(view_win, yscrollcommand=scrollbar.set, wrap='word', padx=10, pady=10)
    for a in appointments:
        text_area.insert(tk.END,
            f"Name: {a['first_name']} {a['last_name']}\n"
            f"Phone: {a['phone']} | National ID: {a['national_id']}\n"
            f"Date: {a['date']} | Time: {a['time']}\n"
            f"Email: {a['email']} | Insurance: {a['insurance']}\n"
            f"Address: {a['address']}\n"
            f"{'-'*40}\n"
        )

    text_area.pack(expand=True, fill='both')
    scrollbar.config(command=text_area.yview)

def open_admin_login():
    login_win = Toplevel(window)
    login_win.title("Admin Login")
    login_win.geometry("300x150")
    login_win.configure(bg="#f8f8f8")

    tk.Label(login_win, text="Enter Admin Password:", bg="#f8f8f8").pack(pady=10)
    entry_pass = tk.Entry(login_win, show="*", width=25)
    entry_pass.pack()

    def check_password():
        if entry_pass.get() == "1234":
            login_win.destroy()
            open_admin_panel()
        else:
            messagebox.showerror("Access Denied", "Wrong password.")

    tk.Button(login_win, text="Login", bg="#007acc", fg="white", command=check_password).pack(pady=10)

def open_admin_panel():
    appointments = load_appointments()
    if not appointments:
        messagebox.showinfo("Admin", "No appointments to manage.")
        return

    panel_win = Toplevel(window)
    panel_win.title("Admin Panel - Delete Appointments")
    panel_win.geometry("550x500")
    panel_win.configure(bg="#f9f9f9")

    canvas = tk.Canvas(panel_win)
    scrollbar = Scrollbar(panel_win, orient="vertical", command=canvas.yview)
    scroll_frame = tk.Frame(canvas)

    scroll_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
    canvas.create_window((0, 0), window=scroll_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)

    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")

    for idx, a in enumerate(appointments):
        frame = tk.Frame(scroll_frame, bd=1, relief="solid", bg="white", padx=10, pady=5)
        frame.pack(fill="x", pady=5, padx=10)

        info = (
            f"{idx+1}. {a['first_name']} {a['last_name']} | {a['date']} at {a['time']}\n"
            f"Phone: {a['phone']} | National ID: {a['national_id']}"
        )
        tk.Label(frame, text=info, justify="left", bg="white").pack(anchor="w")

        def make_delete_func(index):
            return lambda: delete_appointment(index, panel_win)

        tk.Button(frame, text="Delete", bg="red", fg="white", command=make_delete_func(idx)).pack(anchor="e", pady=3)

def delete_appointment(index, panel_win):
    appointments = load_appointments()
    del appointments[index]
    save_appointments(appointments)
    panel_win.destroy()
    open_admin_panel()
    messagebox.showinfo("Deleted", "Appointment has been deleted.")

window = tk.Tk()
window.title("Hospital Appointment System")
window.geometry("400x620")
window.configure(bg="#f0f4f7")

tk.Label(window, text="Patient Information", font=("Arial", 16, "bold"), bg="#f0f4f7").pack(pady=10)

fields = [
    ("First Name *", "first_name"),
    ("Last Name *", "last_name"),
    ("Phone Number *", "phone"),
    ("National ID *", "national_id"),
    ("Email", "email"),
    ("Address", "address"),
    ("Insurance", "insurance")
]

patient_entries = {}
for label_text, key in fields:
    tk.Label(window, text=label_text, bg="#f0f4f7").pack()
    entry = tk.Entry(window, width=40)
    entry.pack(pady=3)
    patient_entries[key] = entry

tk.Button(window, text="Next: Choose Appointment", bg="#007acc", fg="white", command=open_appointment_window).pack(pady=15)
tk.Button(window, text="View All Appointments", bg="#444", fg="white", command=show_appointments).pack(pady=5)
tk.Button(window, text="Admin Login", bg="red", fg="white", command=open_admin_login).pack(pady=5)

window.mainloop()
