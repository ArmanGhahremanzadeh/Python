﻿import pygame
import random

pygame.init()

WIDTH, HEIGHT = 800, 500
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("دایی ناصر")

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 200, 0)

dino_width, dino_height = 50, 50
dino_x, dino_y = 50, HEIGHT - dino_height - 23  
dino_velocity = 8
jumping = False
gravity = 1
jump_speed = 15
velocity_y = 0


obstacle_width, obstacle_height = 30, 50
obstacle_x = WIDTH
obstacle_y = HEIGHT - obstacle_height - 20
obstacle_speed = 10
clock = pygame.time.Clock()
running = True

while running:
    screen.fill(WHITE)
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE and not jumping:
            jumping = True
            velocity_y = -jump_speed

    if jumping:
        dino_y += velocity_y
        velocity_y += gravity
        if dino_y >= HEIGHT - dino_height - 20:
            dino_y = HEIGHT - dino_height - 20
            jumping = False


    obstacle_x -= obstacle_speed
    if obstacle_x < -obstacle_width:
        obstacle_x = WIDTH + random.randint(10, 20)

    if dino_x < obstacle_x + obstacle_width and dino_x + dino_width > obstacle_x:
        if dino_y + dino_height > obstacle_y:
            print("Game Over")
            running = False

    pygame.draw.rect(screen, GREEN, (dino_x, dino_y, dino_width, dino_height))
    pygame.draw.rect(screen, BLACK, (obstacle_x, obstacle_y, obstacle_width, obstacle_height))

    pygame.display.update()
    clock.tick(30)

pygame.quit()

